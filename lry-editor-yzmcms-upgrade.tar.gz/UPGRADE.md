# lry-editor 编辑器升级包（YzmCMS 7.6 / UEditor 替换）

本包将 YzmCMS 的富文本编辑器从 UEditor 1.4.3 替换为 lry-editor（TipTap v3 内核），并为文章评论、留言板接入轻量版 lry-editor-lite。适用于与本包来源完全相同的 YzmCMS 项目，直接覆盖即可完成升级。

## 更新记录

- **v1.4.1（2026-11-25）**：同步上游 lry-editor 1.3 / 1.4 系列。无数据库变更，无后台配置项变更。
  - **可视化自由画板**：流程图 / 思维导图 / UML 类图可直接拖拽编辑；支持节点自由摆放、连线跟随、多选 / 框选、文字 / 图形 / 连线 / 贴纸 / 图片、右键菜单、复制粘贴、缩放与 PNG / SVG 导出。
  - **共享布局层**：节点坐标与自由元素保存在画板图源末尾的 `%% lry-layout v1` 注释块中，Mermaid 会忽略它。新增 `common/static/plugin/lry-editor/lry-diagram-layout.js`，发布端需要还原编辑态布局时按需加载，全局对象为 `window.LryDiagramLayout`。
  - **公式编辑**：KaTeX 编辑态渲染、实时预览、符号面板、双击 / 回车编辑、行内与块级切换；公式存储契约仍为 `\(…\)` / `\[…\]`。
  - **插入槽位**：空段落原位替换、块后自动补可写段落；行柄 / 斜杠 / 工具栏入口统一。
  - **折叠与 Markdown**：折叠块支持真正开合；`:::fold` / `:::cols` / `:::col` 可嵌套，画板与容器导出再导入不丢外壳。
  - **图片对话框**：支持画板选图回调、多图选择与确定后关闭；上传 / 列表 / 抓图仍走站点适配器。
  - **缓存**：`form.class.php` 的 `?v=` 与 5 个前台模板的 lite 资源版本号统一升到 1.4.1，覆盖后自动强刷浏览器缓存。
  - 涉及文件：`common/static/plugin/lry-editor/`（4 个 js/css + 新增 `lry-diagram-layout.js` 与许可证）、`yzmphp/core/class/form.class.php`、`application/index/view/default/` 下 5 个模板。
- **v1.2.1（2026-11-24）**：编辑态代码语法高亮、语言下拉 / 识别、代码块跳出、预告下一行、上下文工具条、表格列宽拖拽、划词工具条、首行缩进、查找替换、导出、AI 智能插入与 lite 待办清单。
- **v1.1.1（2026-11-17）**：修复移动端行柄「+」不可点，并为编辑器资源增加缓存版本号。
- **v1.1.0（2026-11-16）**：首发。UEditor 1.4.3 完整替换 + 评论 / 留言板 lite 接入。

## 一、升级步骤

```bash
# 1. 备份（务必先做）
tar czf /tmp/yzmcms-backup-$(date +%Y%m%d).tar.gz 站点目录

# 2. 解包覆盖（在站点根目录执行，即 index.php 所在目录）
tar xzf lry-editor-yzmcms-upgrade.tar.gz -C /你的站点根目录

# 3. 删除旧编辑器（必须）
rm -rf /你的站点根目录/common/static/plugin/ueditor

# 4. 清空模板编译缓存（必须，否则页面仍使用旧编译模板）
rm -rf /你的站点根目录/cache/*
```

无需任何数据库变更，无后台配置项变更。

## 二、本包替换内容

### 1. 富文本编辑器（后台文章/单页、会员投稿、自定义模型字段、DIY 表单）

- 渲染入口统一改写：`yzmphp/core/class/form.class.php` 的 `form::editor()` / `form::editor_mini()`
  - 编辑器资源（lry-editor.js/css + 上传适配器）自动加载，每页仅一次；
  - 隐藏 `<textarea name="content">` 同步表单字段，原有服务端保存/过滤管线零改动；
  - 旧 UEditor 存量内容无损打开/再保存（内置 normalize/serialize 兼容层）。
- 模板中的 `UE.getEditor()` 调用全部替换为 `LRYEditor.get()`（getContent/setContent/on 同形）。

### 2. 上传/在线附件/远程抓图服务端（新增）

- 新增 `application/attachment/controller/lryeditor.class.php`，端点：
  `index.php?m=attachment&c=lryeditor&a=upload|lists|catchimage`
  - 鉴权与 attachment/api 一致（管理员或登录会员）；
  - 复用系统上传类（支持 host/OSS 等附件存储）、`handle_upload_types` 类型白名单、上传大小限制、附件表登记（yzm_attachment）、水印；
  - list/catchimage 支撑编辑器“在线图片库”与“提取远程图片”功能。
- `attachment/view/upload_box.html` 的 Flash 回退路径改用独立的 `common/static/plugin/webuploader/Uploader.swf`（本包已附带）。

### 3. 评论与留言板轻量富文本（lry-editor-lite）

- 前台评论框（文章/产品/下载页、评论更多页）与留言板表单替换为 lite 编辑器：纯文字排版、划词浮动工具条、字数上限、内置输入清洗。
- 服务端白名单过滤（纵深防御）：
  - `yzmphp/core/function/global.func.php` `remove_xss()` 白名单补充 s/del/code/blockquote；
  - `application/comment/controller/index.class.php`：评论内容先过 `remove_xss()` 白名单再入库；
  - `application/guestbook/controller/index.class.php`：留言内容同样处理，其余字段仍实体转义。
- 存量纯文本评论/留言展示不受影响；新富文本内容按白名单安全渲染。

**已知限制（YzmCMS 原生行为，本包未改动该管线）**：会员投稿（`editor_mini`）的内容在入库前经 YzmCMS 自带的 `remove_xss()` 白名单过滤，`class` / `style` 属性、音视频标签、表格的合并与列宽属性会被剥除（文字、图片、链接、列表、代码块文本保留）。后台发布的内容不经过这道过滤，不受影响。

### 4. 删除内容（升级脚本第 3 步执行）

- `common/static/plugin/ueditor/` 整目录（含其 php 上传端点，已被新端点取代）。

## 三、改动文件清单（相对站点根目录）

```text
yzmphp/core/class/form.class.php                          修改 编辑器渲染入口（v1.4.1 缓存版本）
yzmphp/core/function/global.func.php                      修改 remove_xss 白名单扩充
application/attachment/controller/lryeditor.class.php     新增 上传/列表/抓图端点
application/comment/controller/index.class.php            修改 评论富文本入库过滤
application/guestbook/controller/index.class.php          修改 留言富文本入库过滤
application/admin/view/content_add.html                   修改
application/admin/view/content_edit.html                  修改
application/admin/view/page_content.html                  修改
application/attachment/view/upload_box.html               修改 swf 路径
application/member/view/default/publish.html              修改
application/member/view/default/edit_through.html         修改
application/index/view/default/show_article.html          修改 评论框 lite（v1.4.1 资源版本）
application/index/view/default/show_product.html          修改 评论框 lite（v1.4.1 资源版本）
application/index/view/default/show_download.html         修改 评论框 lite（v1.4.1 资源版本）
application/index/view/default/comment_more.html          修改 评论框 lite（v1.4.1 资源版本）
application/index/view/default/guestbook.html             修改 留言框 lite（v1.4.1 资源版本）
common/static/js/yzm-front.js                             修改 提交前 sync
common/static/plugin/lry-editor/                          编辑器资源
  ├─ lry-editor.js / lry-editor.css                       （full 版 891KB / 45.5KB）
  ├─ lry-editor-lite.js / lry-editor-lite.css             （lite 版 433KB / 5.8KB）
  ├─ lry-diagram-layout.js                                （独立画板布局层 22KB，发布端按需加载）
  └─ third-party/（showdown/mermaid/katex/highlight + 许可证，编辑器内按需懒加载）
common/static/plugin/webuploader/Uploader.swf             新增 迁移自 ueditor
```

## 四、升级后验证

1. 后台添加/编辑文章：工具栏渲染、本地上传/粘贴/拖拽传图（检查 uploads/ 与附件管理有记录）；
2. 打开一篇旧文章：旧内容显示正常，编辑保存后无损；
3. 单页管理、会员中心投稿/编辑投稿正常；
4. 文章页评论框：加粗/表情/链接等排版后提交，评论列表正确展示；
5. 留言板提交富文本留言，后台留言列表/详情正常显示；
6. `grep -rn -i ueditor application/ yzmphp/` 无结果；
7. 编辑含代码块的文章：编辑时代码即有语法着色；文末代码块下方出现带「+」的待写行，连按两次回车可出来继续写正文；插入表格并合并单元格、拖拽列宽，保存后重新打开仍保持；
8. 插入画板并拖动节点、添加文字/贴纸、切换源码再切回，保存后布局不丢；插入公式后可实时预览、双击修改；
9. 如发布端已接入 `lry-diagram-layout.js`，确认前台画板与编辑态节点位置一致。

## 五、回滚

```bash
# 若站点为 git 管理
git checkout -- . && git clean -fd common/static/plugin/lry-editor
# 否则用第一步的备份包覆盖还原
```
