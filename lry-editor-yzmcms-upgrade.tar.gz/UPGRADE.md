# lry-editor 编辑器升级包（YzmCMS 7.6 / UEditor 替换）

本包将 YzmCMS 的富文本编辑器从 UEditor 1.4.3 完整替换为 lry-editor（TipTap v3 内核），
并为文章评论、留言板接入轻量版 lry-editor-lite。适用于与本包来源完全相同的 YzmCMS 项目，
直接覆盖即可完成升级。

## 一、升级步骤

```bash
# 1. 备份（务必先做）
tar czf /tmp/yzmcms-backup-$(date +%Y%m%d).tar.gz 站点目录

# 2. 解包覆盖（在站点根目录执行，即 index.php 所在目录）
tar xzf lry-editor-yzmcms-upgrade.tar.gz -C /你的站点根目录

# 3. 删除旧编辑器（必须）
rm -rf /你的站点根目录/common/static/plugin/ueditor

# 4. 清空模板编译缓存（必须，否则页面仍使用旧编译模板）
rm -rf /你的站点根目录/cache/*
```

无需任何数据库变更，无后台配置项变更。

## 二、本包替换内容

### 1. 富文本编辑器（后台文章/单页、会员投稿、自定义模型字段、DIY 表单）
- 渲染入口统一改写：`yzmphp/core/class/form.class.php` 的 `form::editor()` / `form::editor_mini()`
  - 编辑器资源（lry-editor.js/css + 上传适配器）自动加载，每页仅一次；
  - 隐藏 `<textarea name="content">` 同步表单字段，原有服务端保存/过滤管线零改动；
  - 旧 UEditor 存量内容无损打开/再保存（内置 normalize/serialize 兼容层）。
- 模板中的 `UE.getEditor()` 调用全部替换为 `LRYEditor.get()`（getContent/setContent/on 同形）。

### 2. 上传/在线附件/远程抓图服务端（新增）
- 新增 `application/attachment/controller/lryeditor.class.php`，端点：
  `index.php?m=attachment&c=lryeditor&a=upload|lists|catchimage`
  - 鉴权与 attachment/api 一致（管理员或登录会员）；
  - 复用系统上传类（支持 host/OSS 等附件存储）、`handle_upload_types` 类型白名单、
    上传大小限制、附件表登记（yzm_attachment）、水印；
  - list/catchimage 支撑编辑器"在线图片库"与"提取远程图片"功能。
- `attachment/view/upload_box.html` 的 Flash 回退路径改用独立的
  `common/static/plugin/webuploader/Uploader.swf`（本包已附带）。

### 3. 评论与留言板轻量富文本（lry-editor-lite）
- 前台评论框（文章/产品/下载页、评论更多页）与留言板表单替换为 lite 编辑器：
  纯文字排版（加粗/斜体/下划线/删除线/行内代码/链接/引用/列表/表情）、
  字数上限 1000、内置输入清洗。
- 服务端白名单过滤（纵深防御）：
  - `yzmphp/core/function/global.func.php` `remove_xss()` 白名单补充 s/del/code/blockquote；
  - `application/comment/controller/index.class.php`：评论内容先过 `remove_xss()` 白名单再入库；
  - `application/guestbook/controller/index.class.php`：留言内容同样处理，其余字段仍实体转义。
- 存量纯文本评论/留言展示不受影响；新富文本内容按白名单安全渲染。

### 4. 删除内容（升级脚本第 3 步执行）
- `common/static/plugin/ueditor/` 整目录（含其 php 上传端点，已被新端点取代）。

## 三、改动文件清单（相对站点根目录）

```
yzmphp/core/class/form.class.php                          修改 编辑器渲染入口
yzmphp/core/function/global.func.php                      修改 remove_xss 白名单扩充
application/attachment/controller/lryeditor.class.php     新增 上传/列表/抓图端点
application/comment/controller/index.class.php            修改 评论富文本入库过滤
application/guestbook/controller/index.class.php          修改 留言富文本入库过滤
application/admin/view/content_add.html                   修改
application/admin/view/content_edit.html                  修改
application/admin/view/page_content.html                  修改
application/attachment/view/upload_box.html               修改 swf 路径
application/member/view/default/publish.html              修改
application/member/view/default/edit_through.html         修改
application/index/view/default/show_article.html          修改 评论框 lite
application/index/view/default/show_product.html          修改 评论框 lite
application/index/view/default/show_download.html         修改 评论框 lite
application/index/view/default/comment_more.html          修改 评论框 lite
application/index/view/default/guestbook.html             修改 留言框 lite
common/static/js/yzm-front.js                             修改 提交前 sync
common/static/plugin/lry-editor/                          新增 编辑器资源
  ├─ lry-editor.js / lry-editor.css                       （full 版 610KB/23KB）
  ├─ lry-editor-lite.js / lry-editor-lite.css             （lite 版 413KB/4.5KB）
  └─ third-party/（showdown/mermaid/katex，编辑器内按需懒加载，无需其他配置）
common/static/plugin/webuploader/Uploader.swf             新增 迁移自 ueditor
```

## 四、升级后验证

1. 后台添加/编辑文章：工具栏渲染、本地上传/粘贴/拖拽传图（检查 uploads/ 与附件管理有记录）；
2. 打开一篇旧文章：旧内容显示正常，编辑保存后无损；
3. 单页管理、会员中心投稿/编辑投稿正常；
4. 文章页评论框：加粗/表情/链接等排版后提交，评论列表正确展示；
5. 留言板提交富文本留言，后台留言列表/详情正常显示；
6. `grep -rn -i ueditor application/ yzmphp/` 无结果。

## 五、回滚

```bash
# 若站点为 git 管理
git checkout -- . && git clean -fd common/static/plugin/lry-editor
# 否则用第一步的备份包覆盖还原
```
