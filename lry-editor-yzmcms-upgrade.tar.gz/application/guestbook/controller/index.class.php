<?php
// +----------------------------------------------------------------------
// | Site:  [ http://www.yzmcms.com]
// +----------------------------------------------------------------------
// | Copyright: YuanZhiMeng Studio, All rights reserved
// +----------------------------------------------------------------------
// | Author: YuanZhiMeng <214243830@qq.com>
// +---------------------------------------------------------------------- 
// | Explain: This is not free software. You may only modify and use the program code for non-commercial purposes, and you may not republish the program code in any form for any purpose!
// +----------------------------------------------------------------------

class index{

	private $siteid,$siteinfo,$ip,$module;
	
	public function __construct(){
		$ismobile = ismobile() ? true : false;
		$this->siteid = get_siteid();
		$this->siteinfo = array();
		$this->module = 'index';
		if($this->siteid){
			$this->siteinfo = get_site($this->siteid);
			if($ismobile && $this->siteinfo['site_wap_theme']){
				$this->module = 'mobile';
				set_module_theme($this->siteinfo['site_wap_theme']);
			}else{
				set_module_theme($this->siteinfo['site_theme']);
			}
		}else{
			if($ismobile && get_config('site_wap_open')) {
				$this->module = 'mobile';
				set_module_theme(get_config('site_wap_theme'));
			}
		}
	}
	
	/**
	 * Site guestbook
	 */
	public function init(){	
		new_session_start();
		if(!get_config('is_words')) return_message('The administrator has disabled the guestbook feature!', 0);
		
 		if(is_post()) {
			if(get_config('words_code')){
				!isset($_POST['code']) && return_message(L('code_error'), 0);
				if(empty($_SESSION['code']) || strtolower($_POST['code'])!=$_SESSION['code']){
					$_SESSION['code'] = '';
					return_message(L('code_error'), 0);
				}
				$_SESSION['code'] = '';
			}

			$this->_check($_POST);

			//Message content is entered via the lry-editor-lite rich text editor, filtered with a whitelist; other fields are still entity-escaped
			$bookmsg = remove_xss($_POST['bookmsg']);
			$_POST = new_html_special_chars($_POST);
			$_POST['bookmsg'] = $bookmsg;

			$_POST['siteid'] = $this->siteid;
			$_POST['booktime'] = SYS_TIME;
			$_POST['ip'] = $this->ip;
			$_POST['ispc'] = ismobile() ? 0 : 1;
			$_POST['ischeck'] = $_POST['isread'] = $_POST['replyid'] = 0;
			D('guestbook')->insert($_POST, false);
			
			//Send email notification
			$this->_sendmail($_POST);
			
			return_message('Message submitted successfully, please wait patiently for the administrator to review it!');
		}else{
			$site = array_merge(get_config(), $this->siteinfo);

			list($seo_title, $keywords, $description) = get_site_seo($this->siteid, 'Guestbook Feedback');
			include template($this->module,'guestbook');			
		}
	}
	
	
	/**
	 * Check whether the content is valid
	 */
	private function _check($data){
		if(empty($data['title']) || empty($data['bookmsg']) || empty($data['name'])){
			return_message('Required fields for the message cannot be empty!', 0);
		}

		// IP blacklist verification
		$this->ip = getip();
		$blacklist_ip = get_config('blacklist_ip');
		if($blacklist_ip){
			$arr = explode(',', $blacklist_ip);
			foreach($arr as $val){
				if(check_ip_matching($val, $this->ip)) return_message('Users in the IP blacklist are forbidden to access!', 0);
			}
		}

		if(isset($data['email']) && $data['email'] && !is_email($data['email'])){
			return_message('Incorrect email format!', 0);
		}

		if(isset($data['phone']) && $data['phone'] && !is_mobile($data['phone'])){
			return_message('Incorrect mobile phone number format!', 0);
		}

		if(isset($data['qq']) && $data['qq'] && strlen($data['qq'])>11){
			return_message('Incorrect QQ number length!', 0);
		}

		if(strlen($data['title'])>250){
			return_message('The subject length cannot exceed 250 characters!', 0);
		}

		if(strlen($data['name'])>60){
			return_message('The name length cannot exceed 60 characters!', 0);
		}

		if(isset($data['address']) && strlen($data['address'])>150){
			return_message('The address length cannot exceed 150 characters!', 0);
		}

		// Enable duplicate verification
		$res = D('guestbook')->field('title,name,bookmsg')->order('id DESC')->find();
		if($res && $data['title']==$res['title'] && $data['bookmsg']==$res['bookmsg']){
			return_message('Please do not submit repeatedly!', 0);
		}

		// Enable Chinese verification
		// if(get_config('is_words_chinese')){
		// 	if(!preg_match("/([\x{4e00}-\x{9fa5}]+)/u", $data['title']) || !preg_match("/([\x{4e00}-\x{9fa5}]+)/u", $data['bookmsg'])){
		// 		return_message('Please fill in meaningful content!', 0);
		// 	}
		// }
		
		return true;
	}


	/**
	 * Send email notification
	 */
	private function _sendmail($data){
		$content = strip_tags($data['bookmsg']);
		$site_url = get_config('site_url');
		$html = <<<EOF
	<div style="border:1px solid #dee0e5;color:#676767;width:600px;margin:0 auto;">
        <div style="height:60px;background:#4d5058;line-height:60px;color:#fff;font-size:18px;padding-left:10px;text-align:center;">New Message</div>
        <div style="padding:25px;word-wrap:break-word">
            <div>Message content:</div>
            <div style="padding:10px;background:#f2f2f2;margin:10px 0">$content</div>
            <a href="$site_url" target="_blank" style="color:#22aaff;">Click to view details</a>
        </div>
        <div style="background:#fafafa;color:#b4b4b4;text-align:center;line-height:45px;height:45px;">This is a system email, please do not reply directly</div>
    </div>
EOF;
		sendmail(get_config('mail_inbox'), 'Your website has a new message', $html);
	}

}