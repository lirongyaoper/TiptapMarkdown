<?php
/**
 * lry-editor server-side adapter (upload / online list / remote image catcher)
 *
 * Contract of the lry-editor url adapter (see lry-editor docs/adapter.md):
 *   upload : POST multipart, file field "file", extra fields filetype(1 image, 2 file) and module
 *            => {status:1, data:{url, title, size, filetype}}
 *   list   : GET filetype & start   (action "lists", reserved word safe)
 *            => {status:1, data:{list:[{url, title, mtime}], total}}
 *   catch  : POST source[] (remote image urls, action "catchimage")
 *            => {state:'SUCCESS', list:[{state:'SUCCESS', url, source}]}
 *
 * Endpoint base: index.php?m=attachment&c=lryeditor (see form::_editor_assets())
 *
 * @author           lryper
 * @license          http://www.yzmcms.com
 * @lastmodify       2026-11-16
 */

defined('IN_YZMPHP') or exit('Access Denied');

new_session_start();

class lryeditor{

	private $isadmin;
	private $groupid;
	private $userid;
	private $username;

	public function __construct() {

		$this->userid = isset($_SESSION['adminid']) ? $_SESSION['adminid'] : (isset($_SESSION['_userid']) ? $_SESSION['_userid'] : 0);
		$this->username = isset($_SESSION['adminname']) ? $_SESSION['adminname'] : (isset($_SESSION['_username']) ? $_SESSION['_username'] : '');
		$this->isadmin = isset($_SESSION['roleid']) ? 1 : 0;
		$this->groupid = get_cookie('_groupid') ? intval(get_cookie('_groupid')) : 0;
		if(!$this->userid) return_json(array('status'=>0, 'message'=>L('login_website')));
		if($this->isadmin) define('IN_YZMADMIN', true);

	}



	public function init(){

	}


	/**
	 * Upload file
	 */
	public function upload(){

		$filename = 'file';
		$open_watermark = isset($_POST['open_watermark']) ? intval($_POST['open_watermark']) : 0;
		$filetype = isset($_POST['filetype']) ? intval($_POST['filetype']) : 1;
		$module = isset($_POST['module']) ? htmlspecialchars($_POST['module']) : '';
		$option = array();
		$option['allowtype'] = handle_upload_types($filetype);

		$upload_type = C('upload_type', 'host');
		yzm_base::load_model($upload_type, '', 0);
		if(!class_exists($upload_type)) return_json(array('status'=>0, 'message'=>'The attachment upload class 「'.$upload_type.'」 does not exist!'));
		$upload = new $upload_type($option);
		if($upload->uploadfile($filename)){
			$fileinfo = $upload->getnewfileinfo();
			$fileinfo['module'] = $module;
			$fileinfo['originname'] = safe_replace($fileinfo['originname']);
			$attid = $this->_att_write($fileinfo);
			$url = $fileinfo['filepath'].$fileinfo['filename'];
			if($open_watermark) watermark($url);
			return_json(array(
				'status' => 1,
				'data' => array(
					'url' => $url,
					'title' => $fileinfo['originname'],
					'size' => $fileinfo['filesize'],
					'filetype' => $fileinfo['filetype'],
					'attid' => $attid,
					'delurl' => U('attachment/api/delete', array('id'=>$attid))
				)
			));
		}else{
			return_json(array(
				'status' => 0,
				'message' => $upload->geterrormsg()
			));
		}
	}


	/**
	 * Online attachment list (insert image / file dialog)
	 */
	public function lists(){
		$filetype = isset($_GET['filetype']) ? intval($_GET['filetype']) : 1;  //1 image type, 2 file type
		$start = isset($_GET['start']) ? intval($_GET['start']) : 0;
		$limit = 40;

		$where = array();
		$where['isimage'] = $filetype == 1 ? 1 : 0;
		if(!$this->isadmin) $where['userid'] = $this->userid;

		$attachment = D('attachment');
		$total = $attachment->where($where)->total();
		$data = $attachment->field('id,filepath,filename,originname,uploadtime')->where($where)->order('id DESC')->limit($start.','.$limit)->select();

		$list = array();
		if(is_array($data)){
			foreach($data as $val){
				$list[] = array(
					'url' => $val['filepath'].$val['filename'],
					'title' => $val['originname'],
					'mtime' => $val['uploadtime']
				);
			}
		}

		return_json(array('status'=>1, 'data'=>array('list'=>$list, 'total'=>intval($total))));
	}


	/**
	 * Catch remote images (wordimage batch transfer)
	 */
	public function catchimage(){
		$sources = isset($_POST['source']) && is_array($_POST['source']) ? $_POST['source'] : array();
		if(!$sources) return_json(array('state'=>'ERROR', 'list'=>array()));

		$list = array();
		foreach($sources as $value){
			$value = trim($value);
			if(strpos($value, 'http') !== 0){
				$list[] = array('state'=>'ERROR', 'source'=>$value);
				continue;
			}

			//Ignore the current site and the configured domains
			$down_ignore_domain = get_config('down_ignore_domain');
			$down_ignore_domain = $down_ignore_domain ? explode(',', $down_ignore_domain) : array();
			array_push($down_ignore_domain, HTTP_HOST);
			$ignored = false;
			foreach($down_ignore_domain as $ignore_domain){
				if($ignore_domain && stristr($value, $ignore_domain)){ $ignored = true; break; }
			}
			if($ignored){ $list[] = array('state'=>'ERROR', 'source'=>$value); continue; }

			$url = strpos($value, '?') ? explode('?', $value) : array($value);
			$url = $url[0];
			$ext = fileext($url);
			if(!is_img($ext)){ $list[] = array('state'=>'ERROR', 'source'=>$value); continue; }

			$list[] = $this->_download_image($url, $value);
		}

		$success = 0;
		foreach($list as $val){ if($val['state'] == 'SUCCESS') $success++; }
		return_json(array('state'=>$success ? 'SUCCESS' : 'ERROR', 'list'=>$list));
	}


	/**
	 * Download one remote image and register it as an attachment
	 */
	private function _download_image($url, $source){

		$path = C('upload_file').'/'.date('Ym/d');
		$urlpath = SITE_PATH.$path;
		$imgpath = YZMPHP_PATH.$path;
		if(!is_dir($imgpath)) @mkdir($imgpath, 0777, true);

		$imgname = date('YmdHis').rand(100,999).'.'.fileext($url);
		$filename = $imgpath.'/'.$imgname;

		ob_start();
		readfile($url);
		$data = ob_get_contents();
		ob_end_clean();
		$len = $data ? file_put_contents($filename, $data) : 0;
		if(!$len) return array('state'=>'ERROR', 'source'=>$source);

		$arr = array(
			'siteid' => get_siteid(),
			'originname' => 'Remote download-'.htmlspecialchars(basename($url)),
			'filename' => $imgname,
			'filepath' => $urlpath.'/',
			'filesize' => $len,
			'fileext' => fileext($url),
			'module' => 'lryeditor',
			'isimage' => 1,
			'downloads' => 0,
			'userid' => $this->userid,
			'username' => $this->username,
			'uploadtime' => SYS_TIME,
			'uploadip' => getip()
		);
		D('attachment')->insert($arr);

		return array('state'=>'SUCCESS', 'url'=>$urlpath.'/'.$imgname, 'source'=>$source);
	}


	/**
	 * Write the uploaded attachment to the database
	 */
	private function _att_write($fileinfo){
		$arr = array();
		$arr['siteid'] = get_siteid();
		$arr['originname'] = strlen($fileinfo['originname'])<50 ? htmlspecialchars($fileinfo['originname']) : htmlspecialchars(str_cut($fileinfo['originname'], 50));
		$arr['filename'] = $fileinfo['filename'];
		$arr['filepath'] = $fileinfo['filepath'];
		$arr['filesize'] = $fileinfo['filesize'];
		$arr['fileext'] = $fileinfo['filetype'];
		$arr['module'] = $fileinfo['module'];
		$arr['isimage'] = is_img($fileinfo['filetype']) ? 1 : 0;
		$arr['downloads'] = 0;
		$arr['userid'] = $this->userid;
		$arr['username'] = $this->username;
		$arr['uploadtime'] = SYS_TIME;
		$arr['uploadip'] = getip();
		return D('attachment')->insert($arr);
	}

}
