<?php
/**
 * form.class.php  form class
 *
 * @author           YuanZhiMeng  
 * @license          http://www.yzmcms.com
 * @lastmodify       2016-12-10 
 */

class form {

	/**
	 * Whether the lry-editor assets have been loaded on this page
	 */
	private static $editor_loaded = false;

	/**
	 * input
	 * @param $name name
	 * @param $value default value, e.g. YzmCMS
	 * @param $required  whether it is required, defaults to false
	 * @param $width  width, e.g. 100
	 * @param $attribute extra attribute
	 */
	public static function input($name = '', $value = '', $required=false, $width = 0, $attribute='') {
		$string = '<input class="yzm-input-text" ';
		if($width) $string .= ' style="width:'.$width.'px" ';
		if($required) $string .= ' required="required" ';
		$string .= ' name="'.$name.'" id="'.$name.'" '.$attribute;
		$string .= ' type="text" value="'.$value.'">';
		return $string;
	}


	/**
	 * number 
	 * @param $name name
	 * @param $value default value, e.g. 0
	 * @param $required  whether it is required, defaults to false
	 * @param $width  width, e.g. 100
	 * @param $attribute extra attribute
	 */
	public static function number($name = '', $value = '', $required=false, $width = 0, $attribute='') {
		$string = '<input class="yzm-input-text" ';
		if($width) $string .= ' style="width:'.$width.'px" ';
		if($required) $string .= ' required="required" ';
		$string .= ' name="'.$name.'" id="'.$name.'" '.$attribute;
		$string .= ' type="number" value="'.$value.'">';
		return $string;
	}
		

	/**
	 * textarea
	 * @param $name name
	 * @param $value default value, e.g. YzmCMS
	 * @param $required  whether it is required, defaults to false
	 * @param $width  width, e.g. 100
	 * @param $attribute extra attribute
	 */
	public static function textarea($name = '', $value = '', $required=false, $width = 0, $attribute='') {
		$string = '<textarea class="textarea yzm-textarea" name="'.$name.'" id="'.$name.'" ';
		if($width) $string .= ' width="'.$width.'px" ';
		if($required) $string .= ' required="required" ';
		$string .= $attribute.' >'.$value.'</textarea>';
		return $string;
	}

	
	/**
	 * Dropdown select box
	 * @param $name name
	 * @param $val default selected value, e.g. 1
	 * @param $array one-dimensional array, e.g. array('Transaction succeeded', 'Transaction failed', 'Transaction result unknown');
	 * @param $default_option prompt text e.g. Please select transaction 
	 * @param $attribute extra attribute
	 */
	public static function select($name, $val = 0, $array = array(), $default_option = '', $attribute='') {
		$string = '<select name="'.$name.'" id="'.$name.'" class="select yzm-select" '.$attribute.'>';
		if($default_option) $string .= "<option value=''>$default_option</option>";
		if(!is_array($array) || count($array)== 0) return false;
		$ids = array();
		if(isset($val)) $ids = explode(',', $val);
		foreach($array as $value) {
			$arr = explode(':', $value);
			$key = trim($arr[0]);
			$value = isset($arr[1]) ? $arr[1] : $arr[0];  
			$selected = in_array($key, $ids) ? 'selected' : '';
			$string .= '<option value="'.$key.'" '.$selected.'>'.$value.'</option>';
		}
		$string .= '</select>';
		return $string;
	}
	
	
	/**
	 * Checkbox
	 * 
	 * @param $name name
	 * @param $val default selected value; separate multiple values with a comma, e.g. '1,2'
	 * @param $array one-dimensional array, e.g. array('Transaction succeeded', 'Transaction failed', 'Transaction result unknown');
	 */
	public static function checkbox($name, $val = '', $array = array()) {
		$string = '<input type="hidden" name="'.$name.'" value="">';
		$val = trim($val);
		if($val != '') $val = strpos($val, ',') ? explode(',', $val) : array($val);
		$i = 1;
		foreach($array as $value) {
			$arr = explode(':', $value);
			$key = trim($arr[0]);
			$value = isset($arr[1]) ? $arr[1] : $arr[0]; 
			$checked = ($val && in_array($key, $val)) ? 'checked' : '';
			$string .= '<label class="option_label option_box" >';
			$string .= '<input type="checkbox" class="yzm-checkbox" name="'.$name.'[]" id="'.$name.'_'.$i.'" '.$checked.' value="'.$key.'">'.$value;
			$string .= '</label>';
			$i++;
		}
		return $string;
	}

	
	/**
	 * Radio box
	 * 
	 * @param $name name
	 * @param $val default selected value, e.g. 1
	 * @param $array one-dimensional array, e.g. array('Transaction succeeded', 'Transaction failed', 'Transaction result unknown');
	 */
	public static function radio($name, $val = 0, $array = array()) {
		$string = '';
		foreach($array as $value) {
			$arr = explode(':', $value);
			$key = trim($arr[0]);
			$value = isset($arr[1]) ? $arr[1] : $arr[0]; 
			$checked = trim($val)==$key ? 'checked' : '';
			$string .= '<label class="option_label option_radio" >';
			$string .= '<input type="radio" class="yzm-radio" name="'.$name.'" id="'.$name.'_'.$key.'" '.$checked.' value="'.$key.'">'.$value;
			$string .= '</label>';
		}
		return $string;
	}
	
	
	/**
	 * Verification code
	 * @param string $id   verification code ID
	 */
	public static function code($id='code') {
		return '<img src="'.U('api/index/code/').'" id="'.$id.'" onclick="this.src=this.src+\'?\'" style="cursor:pointer;" title="Cannot read it clearly? Click to refresh">';
	}
	
	
	/**
	 * Date-time control
	 * 
	 * @param $name name
	 * @param $val default value
	 * @param $isdatetime whether to show hours, minutes and seconds
	 * @param $loadjs whether to load the js again, to prevent the control from failing to display due to irregular script loading on the page
	 * @param $attribute extra attribute
	 */
	public static function datetime($name, $val = '', $isdatetime = 0, $loadjs = 0, $attribute = '') {		
		$string = '';
		if($loadjs || !defined('DATETIME')) {
			define('DATETIME', 1);
			$string .= '<script type="text/javascript" src="'.STATIC_URL.'plugin/laydate/1.1/laydate.js"></script>';
		}
		
		$string .= '<input class="laydate-icon date"  value="'.$val.'" name="'.$name.'" id="'.$name.'" '.$attribute.'>';	
		$string .= '<script type="text/javascript"> laydate({elem: "#'.$name.'",';
		if($isdatetime) $string .= 'istime: true,format: "YYYY-MM-DD hh:mm:ss",';
		$string .= '});</script>';
		return $string;
	}
	
	
	/**
	 * Image upload
	 * 
	 * @param $name name
	 * @param $val default value
	 * @param $style style
	 * @param $attribute extra attribute	 
	 */
	public static function image($name, $val = '', $style = '', $iscropper = false, $attribute = '') {	
		$style = $style ? $style : 'width:370px';		
		$string = '<input type="hidden" name="'.$name.'_attid" id="'.$name.'_attid" value="0"><input class="input-text uploadfile" type="text" name="'.$name.'"  value="'.$val.'"  onmouseover="yzm_img_preview(\''.$name.'\', this.value)" onmouseout="layer.closeAll();" id="'.$name.'" style="'.$style.'" '.$attribute.'> <a href="javascript:;" onclick="yzm_upload_att(\''.U('attachment/api/upload_box', array('module'=>ROUTE_M, 'pid'=>$name), false).'\')" class="btn btn-primary radius upload-btn"><i class="yzm-iconfont yzm-iconshangchuan"></i> Browse files</a>';
		
		if($iscropper) $string = $string .' '.form::cropper($name);
		return $string;
	}
	
	
	/**
	 * Multiple image upload
	 * 
	 * @param $name name
	 * @param $val default value
	 * @param $n upload count
	 */
	public static function images($name, $val = '', $n = 20) {
		$n = $n ? $n : 20;
		$string = '';
		$string .= '<fieldset class="fieldset_list"><legend>Image list</legend><div class="fieldset_tip">You can upload up to <span style="color:red">'.$n.'</span> files at the same time</div>
					<input type="hidden" name="'.$name.'" value="">
					<ul id="'.$name.'" class="file_ul">';
		if($val){
			$arr = string2array($val);
			foreach($arr as $key => $val){
				$string .= '<li>File: <input type="text" name="'.$name.'[url][]" value="'.$val['url'].'" id="'.$name.'_'.$key.'" onmouseover="yzm_img_preview(\''.$name.'_'.$key.'\', this.value)" onmouseout="layer.closeAll();" class="input-text yzm-input-url"> Description: <input type="text" name="'.$name.'[alt][]" value="'.$val['alt'].'" class="input-text yzm-input-alt"><a href="javascript:;" class="secondary" onclick="yzm_move_li(this, 1);">Move up</a> <a href="javascript:;" class="secondary" onclick="yzm_move_li(this, 0);">Move down</a> <a href="javascript:;" class="danger" onclick="yzm_delete_li(this);">Delete</a></li>';
			}
		}					
		$string .= 	'</ul></fieldset>
				<a href="javascript:;" onclick="yzm_upload_att(\''.U('attachment/api/upload_box', array('module'=>ROUTE_M, 'pid'=>$name, 'n'=>$n), false).'\')" class="btn btn-primary radius upload-btn mt-5"><i class="yzm-iconfont yzm-iconshangchuan"></i> Browse files</a> <a href="javascript:;" onclick="yzm_add_attachment(\''.$name.'\')" class="btn btn-secondary radius upload-btn mt-5"><i class="yzm-iconfont yzm-icontianjia"></i> Add remote URL</a>';
		
		return $string;
	}
	

	/**
	 * Image crop
	 * 
	 * @param $cid 		the id of the input holding the original image
	 * @param $spec  	crop rule，1：4*3, 2:3*2, 3:1*1, 4:2*3
	 */
	public static function cropper($cid, $spec=2) {		
		$string = '<a href="javascript:;" onclick="yzm_img_cropper(\''.$cid.'\', \''.U('attachment/api/img_cropper', array('spec'=>$spec), false).'\')" class="btn btn-secondary radius upload-btn"><i class="yzm-iconfont yzm-iconcaijian"></i> Crop image</a>';
		
		return $string;
	}
	
	
	/**
	 * Attachment upload
	 * 
	 * @param $name name
	 * @param $val default value
	 * @param $style style
	 * @param $attribute extra attribute	
	 */
	public static function attachment($name, $val = '', $style='', $attribute='') {
		$style = $style ? $style : 'width:370px';		
		$string = '<input type="hidden" name="'.$name.'_attid" id="'.$name.'_attid" value="0"><input class="input-text uploadfile" type="text" name="'.$name.'"  value="'.$val.'"  id="'.$name.'" style="'.$style.'" '.$attribute.'> <a href="javascript:;" onclick="yzm_upload_att(\''.U('attachment/api/upload_box', array('module'=>ROUTE_M, 'pid'=>$name, 't'=>2), false).'\')" class="btn btn-primary radius upload-btn"><i class="yzm-iconfont yzm-iconshangchuan"></i> Browse files</a>';
		
		return $string;
	}	
	
	
	/**
	 * Multiple file upload
	 * 
	 * @param $name name
	 * @param $val default value
	 * @param $n upload count
	 */
	public static function attachments($name, $val = '', $n = 20) {
		$n = $n ? $n : 20;
		$string = '';
		$string .= '<fieldset class="fieldset_list"><legend>File list</legend><div class="fieldset_tip">You can upload up to <span style="color:red">'.$n.'</span> files at the same time</div>
					<input type="hidden" name="'.$name.'" value="">
					<ul id="'.$name.'" class="file_ul">';
		if($val){
			$arr = string2array($val);
			foreach($arr as $key => $val){
				$string .= '<li>File: <input type="text" name="'.$name.'[url][]" value="'.$val['url'].'" id="'.$name.'_'.$key.'" class="input-text yzm-input-url"> Description: <input type="text" name="'.$name.'[alt][]" value="'.$val['alt'].'" class="input-text yzm-input-alt"><a href="javascript:;" class="secondary" onclick="yzm_move_li(this, 1);">Move up</a> <a href="javascript:;" class="secondary" onclick="yzm_move_li(this, 0);">Move down</a> <a href="javascript:;" class="danger" onclick="yzm_delete_li(this);">Delete</a></li>';
			}
		}					
		$string .= 	'</ul></fieldset>
				<a href="javascript:;" onclick="yzm_upload_att(\''.U('attachment/api/upload_box', array('module'=>ROUTE_M, 'pid'=>$name, 'n'=>$n, 't'=>2), false).'\')" class="btn btn-primary radius upload-btn mt-5"><i class="yzm-iconfont yzm-iconshangchuan"></i> Browse files</a> <a href="javascript:;" onclick="yzm_add_attachment(\''.$name.'\')" class="btn btn-secondary radius upload-btn mt-5"><i class="yzm-iconfont yzm-icontianjia"></i> Add remote URL</a>';
		
		return $string;
	}

	
	/**
	 * Load lry-editor assets (css/js/upload adapter), only once per page
	 */
	private static function _editor_assets() {
		if(self::$editor_loaded) return '';
		self::$editor_loaded = true;
		/* LRY_EDITOR_VER:资源版本号,升级包发布时同步递增,强刷浏览器缓存 */
		$ver = '1.2.1';
		return '<script type="text/javascript">
			window.LRY_EDITOR_BASE = window.LRY_EDITOR_BASE || \''.STATIC_URL.'plugin/lry-editor/\';
			window.LRY_EDITOR_KATEX = window.LRY_EDITOR_KATEX || \''.STATIC_URL.'plugin/lry-editor/third-party/katex\';
			</script>
			<link rel="stylesheet" type="text/css" href="'.STATIC_URL.'plugin/lry-editor/lry-editor.css?v='.$ver.'">
			<script type="text/javascript" charset="utf-8" src="'.STATIC_URL.'plugin/lry-editor/lry-editor.js?v='.$ver.'"></script>
			<script type="text/javascript">
			if(window.LRYEditor && !LRYEditor._yzmAdapter){
				LRYEditor._yzmAdapter = 1;
				LRYEditor.setAdapter(LRYEditor.createUrlAdapter({
					base:\''.SITE_PATH.'index.php?m=attachment&c=lryeditor\',
					listUrl:\''.SITE_PATH.'index.php?m=attachment&c=lryeditor&a=lists\',
					catchUrl:\''.SITE_PATH.'index.php?m=attachment&c=lryeditor&a=catchimage\'
				}));
			}
			</script>';
	}


	/**
	 * Editor
	 *
	 * @param $name name
	 * @param $val default value
	 * @param $style style, only height is parsed, e.g. width:100%;height:400px
	 * @param $isload deprecated, assets are loaded automatically
	 */
	public static function editor($name = 'content', $val = '', $style='', $isload=false) {
		$style = $style ? $style : 'width:100%;height:400px';
		$height = preg_match('/height\s*:\s*(\d+)/i', $style, $matches) ? intval($matches[1]) : 400;
		$string = self::_editor_assets();
		$string .= '<textarea id="'.$name.'" name="'.$name.'" style="display:none;">'.htmlspecialchars($val).'</textarea>
			<script type="text/javascript">LRYEditor.create({mount: \'#'.$name.'\', height: '.$height.', preset: \'full\'}); </script>';

		return $string;
	}


	/**
	 * Editor - Mini version
	 *
	 * @param $name name
	 * @param $val default value
	 * @param $style style, only height is parsed, e.g. width:100%;height:300px
	 * @param $isload deprecated, assets are loaded automatically
	 */
	public static function editor_mini($name = 'content', $val = '', $style='', $isload=false) {
		$style = $style ? $style : 'width:100%;height:300px';
		$height = preg_match('/height\s*:\s*(\d+)/i', $style, $matches) ? intval($matches[1]) : 300;
		$string = self::_editor_assets();
		$string .= '<textarea id="'.$name.'" name="'.$name.'" style="display:none;">'.htmlspecialchars($val).'</textarea>
			<script type="text/javascript">LRYEditor.create({mount: \'#'.$name.'\', height: '.$height.', preset: \'mini\', wordCount: false, elementPath: false}); </script>';

		return $string;
	}
	
}
