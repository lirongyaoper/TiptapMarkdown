<?php
/**
 * global.func.php   common function library
 *
 * @author           YuanZhiMeng  
 * @license          http://www.yzmcms.com
 * @lastmodify       2017-05-25
 */
 

/**
 * http/https request, supports get and post
 * @param  string  $url   the request URL
 * @param  string  $data  POST request; the array must not be empty
 * @param  boolean $array whether to return as an array
 * @param  int     $timeout set the timeout (milliseconds)
 * @param  array   $header the request headers
 * @return array|string
 */
function https_request($url, $data = '', $array = true, $timeout = 2000, $header = array()){
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_NOSIGNAL, true); 
    curl_setopt($curl, CURLOPT_TIMEOUT_MS, $timeout); 

    if($data){
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    }

	if($header){
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	}
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $output = curl_exec($curl);
    debug::addmsg(array('url'=>$url, 'data'=>$data), 2);
	if($output === false) {
		$curl_error = curl_error($curl);
		return $array ? array('status'=>0, 'message'=>$curl_error) : $curl_error;
	}
    safe_curl_close($curl);
    return $array ? json_decode($output, true) : $output;
}


/**
 * String truncation
 * @param  string $string the string to truncate
 * @param  int    $length the truncation length
 * @param  string  $dot	  the marker used after truncation
 * @param  string  $code  the encoding format, supports UTF8/GBK
 * @return string
 */
function str_cut($string, $length, $dot = '...', $code = 'utf-8') {
	$strlen = strlen($string);
	if($strlen <= $length) return $string;
	$string = str_replace(array(' ','&nbsp;', '&amp;', '&quot;', '&#039;', '&ldquo;', '&rdquo;', '&mdash;', '&lt;', '&gt;', '&middot;', '&hellip;'), array('∵',' ', '&', '"', "'", '“', '”', '—', '<', '>', '·', '…'), $string);
	$strcut = '';
	if($code == 'utf-8') {
		$length = intval($length-strlen($dot)-$length/3);
		$n = $tn = $noc = 0;
		while($n < strlen($string)) {
			$t = ord($string[$n]);
			if($t == 9 || $t == 10 || (32 <= $t && $t <= 126)) {
				$tn = 1; $n++; $noc++;
			} elseif(194 <= $t && $t <= 223) {
				$tn = 2; $n += 2; $noc += 2;
			} elseif(224 <= $t && $t <= 239) {
				$tn = 3; $n += 3; $noc += 2;
			} elseif(240 <= $t && $t <= 247) {
				$tn = 4; $n += 4; $noc += 2;
			} elseif(248 <= $t && $t <= 251) {
				$tn = 5; $n += 5; $noc += 2;
			} elseif($t == 252 || $t == 253) {
				$tn = 6; $n += 6; $noc += 2;
			} else {
				$n++;
			}
			if($noc >= $length) {
				break;
			}
		}
		if($noc > $length) {
			$n -= $tn;
		}
		$strcut = substr($string, 0, $n);
		$strcut = str_replace(array('∵', '&', '"', "'", '“', '”', '—', '<', '>', '·', '…'), array(' ', '&amp;', '&quot;', '&#039;', '&ldquo;', '&rdquo;', '&mdash;', '&lt;', '&gt;', '&middot;', '&hellip;'), $strcut);
	} else {
		$dotlen = strlen($dot);
		$maxi = $length - $dotlen - 1;
		$current_str = '';
		$search_arr = array('&',' ', '"', "'", '“', '”', '—', '<', '>', '·', '…','∵');
		$replace_arr = array('&amp;','&nbsp;', '&quot;', '&#039;', '&ldquo;', '&rdquo;', '&mdash;', '&lt;', '&gt;', '&middot;', '&hellip;',' ');
		$search_flip = array_flip($search_arr);
		for ($i = 0; $i < $maxi; $i++) {
			$current_str = ord($string[$i]) > 127 ? $string[$i].$string[++$i] : $string[$i];
			if (in_array($current_str, $search_arr)) {
				$key = $search_flip[$current_str];
				$current_str = str_replace($search_arr[$key], $replace_arr[$key], $current_str);
			}
			$strcut .= $current_str;
		}
	}
	return $strcut.$dot;
}


/**
 * XSS filter function
 * @param  string  $string the string to filter
 * @return string
 */
function remove_xss($string) {
    if (!is_string($string) || $string === '') {
        return $string;
    }

    $string = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]+/S', '', $string);

    $allowed_tags = array(
        'a', 'b', 'strong', 'i', 'em', 'u', 's', 'del', 'code', 'blockquote', 'p', 'br', 'div', 'span', 'ul', 'ol', 'li', 'pre',
        'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'img',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6'
    );

    $allowed_attributes = array(
        '*' => array('title', 'alt'),
        'a' => array('href', 'title', 'target', 'rel'),
        'img' => array('src', 'alt', 'title', 'width', 'height')
    );

    $string = preg_replace_callback('/<\s*(\/?)\s*([a-zA-Z0-9]+)([^>]*)>/s', function($matches) use ($allowed_tags, $allowed_attributes) {
        $closing = $matches[1];
        $tag = strtolower($matches[2]);
        $attr_text = $matches[3];

        if (!in_array($tag, $allowed_tags)) {
            return '';
        }

        if ($closing) {
            return '</' . $tag . '>';
        }

        $allowed = isset($allowed_attributes[$tag]) ? array_merge($allowed_attributes['*'], $allowed_attributes[$tag]) : $allowed_attributes['*'];
        $attr_text = trim($attr_text);
        $safe_attrs = '';
        $attr_values = array();

        // Fix the bypass issue where attribute names contain quotes
        if (preg_match_all('/([^\s=\/>]+)(\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\"\'>\s]+)))?/s', $attr_text, $attr_matches, PREG_SET_ORDER)) {
            foreach ($attr_matches as $attr_match) {
                $name = $attr_match[1];
                $decoded_name = html_entity_decode($name, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $decoded_name = rawurldecode($decoded_name);
                // Clean control characters inside the attribute name
                $normalized_name = strtolower(preg_replace('/[\s\x00-\x1F\x7F]+/u', '', $decoded_name));

                // Filter all event attributes starting with on
                if (strpos($normalized_name, 'on') === 0) {
                    continue;
                }

                if (!in_array($normalized_name, $allowed)) {
                    continue;
                }

                $value = '';
                if (isset($attr_match[3]) && $attr_match[3] !== '') {
                    $value = $attr_match[3];
                } elseif (isset($attr_match[4]) && $attr_match[4] !== '') {
                    $value = $attr_match[4];
                } elseif (isset($attr_match[5]) && $attr_match[5] !== '') {
                    $value = $attr_match[5];
                }

				// href/src protocol check; detected after decoding entities and percent-encoding
                if ($normalized_name === 'href' || $normalized_name === 'src') {
                    $value = trim($value);
                    $decoded = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    $decoded = rawurldecode($decoded);
                    $normalized_value = strtolower(preg_replace('/[\s\x00-\x1F\x7F]+/u', '', $decoded));

                    if (preg_match('/^(javascript|vbscript|file|about|view-source):/i', $normalized_value)) {
                        continue;
                    }

                    if (strpos($normalized_value, 'data:') === 0) {
                        if (!preg_match('/^data:image\/(png|jpe?g|gif|webp|bmp)(;|,)/i', $normalized_value)) {
							continue;
						}
					}
                }

                $attr_values[$normalized_name] = $value;
            }
        }

        if ($tag === 'a' && isset($attr_values['target']) && strtolower(trim($attr_values['target'])) === '_blank') {
            $rel_values = isset($attr_values['rel']) ? preg_split('/\s+/', trim($attr_values['rel']), -1, PREG_SPLIT_NO_EMPTY) : array();
            $lower_rels = array_map('strtolower', $rel_values);
            if (!in_array('noopener', $lower_rels, true)) {
                $rel_values[] = 'noopener';
            }
            $attr_values['rel'] = trim(implode(' ', array_unique($rel_values)));
        }

        $safe_attrs = '';
        foreach ($attr_values as $name => $value) {
            $safe_attrs .= ' ' . $name . '="' . htmlspecialchars($value, ENT_QUOTES | ENT_HTML5) . '"';
        }

        return '<' . $tag . $safe_attrs . '>';
    }, $string);

    return $string;
}


/**
 * Safe filter function
 * @param  string  $string the string to filter
 * @return string
 */
function safe_replace($string) {
	if(!is_string($string)) return $string;
	$string = trim($string);
	$string = str_replace('%20','',$string);
	$string = str_replace('%27','',$string);
	$string = str_replace('%2527','',$string);
	$string = str_replace('*','',$string);
	$string = str_replace('"','',$string);
	$string = str_replace("'",'',$string);
	$string = str_replace(';','',$string);
	$string = str_replace('<','&lt;',$string);
	$string = str_replace('>','&gt;',$string);
	$string = str_replace("{",'',$string);
	$string = str_replace('}','',$string);
	$string = str_replace('\\','',$string);
	return $string;
}	


/**
 * Get the full URL of the current page
 * @return string
 */
function get_url() {
	$sys_protocal = is_ssl() ? 'https://' : 'http://';
	$php_self = $_SERVER['PHP_SELF'] ? safe_replace($_SERVER['PHP_SELF']) : safe_replace($_SERVER['SCRIPT_NAME']);
	$path_info = isset($_SERVER['PATH_INFO']) ? safe_replace($_SERVER['PATH_INFO']) : '';
	$relate_url = isset($_SERVER['REQUEST_URI']) ? safe_replace($_SERVER['REQUEST_URI']) : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.safe_replace($_SERVER['QUERY_STRING']) : $path_info);
	return $sys_protocal.HTTP_HOST.$relate_url;
}


/**
 * Get the request IP
 * @return string
 */
function getip(){
	$ip = '';
	if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
		$ip = getenv('HTTP_CLIENT_IP');
	} elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
		$ip = getenv('HTTP_X_FORWARDED_FOR');
	} elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
		$ip = getenv('REMOTE_ADDR');
	} elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : '127.0.0.1';
}


/**
 * Get the request region
 * @param string $ip the IP address
 * @param bool $is_array whether to return as an array
 * @return string|array
 */
function get_address($ip, $is_array = false){
	if($ip == '127.0.0.1') return 'Local address';
	$content = @file_get_contents('http://api.yzmcms.com/api/ip/?ip='.$ip);
	$arr = json_decode($content, true);
	if(is_array($arr) && !isset($arr['error'])){
		return $is_array ? $arr : ($arr['country'] .'-'. $arr['province'] . (!empty($arr['city']) ? '-' . $arr['city'] : ''));
	}else{
		return $is_array&&is_array($arr) ? $arr : 'Unknown';
	}
}


/**
 * Check whether the IP matches
 * @param  string  $ip_vague the IP or IP range to check; an IP range is indicated by (*)
 * @param  string  $ip       the IP being checked; defaults to the current request IP
 * @return bool
 */
function check_ip_matching($ip_vague, $ip = ''){
	empty($ip) && $ip = getip();
	if(strpos($ip_vague,'*') === false){
		return $ip_vague == $ip;
	}
	if(count(explode('.', $ip_vague)) != 4) return false;
	$min_ip = str_replace('*', '0', $ip_vague);
	$max_ip = str_replace('*', '255', $ip_vague);
	$ip = ip2long($ip);
	if($ip>=ip2long($min_ip) && $ip<=ip2long($max_ip)){  
		return true; 
	}
	return false;
}


/**
* Generate a random string
* @param  int  $length  the output length
* @param  string  $chars   optional; defaults to 0123456789
* @return string string
*/
function random($length, $chars = '0123456789') {
	$hash = '';
	$max = strlen($chars) - 1;
	for($i = 0; $i < $length; $i++) {
		$hash .= $chars[mt_rand(0, $max)];
	}
	return $hash;
}


/**
 * Generate a random string
 * @param string $lenth length
 * @return string string
 */
function create_randomstr($lenth = 6) {
	return random($lenth, '123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ');
}


/**
* Create an order number
* @return string string
*/
function create_tradenum(){
	return date('YmdHis').random(4);
}


/**
 * Return a string or array processed by addslashes
 * @param  string  $string the string or array to process
 * @return mixed
 */
function new_addslashes($string){
	if(!is_array($string)) return addslashes($string);
	foreach($string as $key => $val) $string[$key] = new_addslashes($val);
	return $string;
}


/**
 * Return a string or array processed by stripslashes
 * @param  string  $string the string or array to process
 * @return mixed
 */
function new_stripslashes($string) {
	if(!is_array($string)) return stripslashes($string);
	foreach($string as $key => $val) $string[$key] = new_stripslashes($val);
	return $string;
}


/**
 * Return a string or array processed by htmlspecialchars
 * @param  string  $string the string or array to process
 * @param  array   $filter the fields to exclude, in array format	
 * @return mixed
 */
function new_html_special_chars($string, $filter = array()) {
	if(!is_array($string)) return htmlspecialchars($string,ENT_QUOTES,'utf-8');
	foreach($string as $key => $val){
		$string[$key] = $filter&&in_array($key, $filter) ? $val : new_html_special_chars($val, $filter);
	}
	return $string;
}


/**
 * Compatible json_encode for lower PHP versions
 * @param  array   $array
 * @param  integer $options
 * @param  integer $depth 
 * @return string|false
 */
function new_json_encode($array, $options = 0, $depth = 0){
	if(version_compare(PHP_VERSION,'5.4.0','<')) {
	    $jsonstr = json_encode($array);
	}else{
	    $jsonstr = $depth ? json_encode($array, $options, $depth) : json_encode($array, $options);
	}   
	return $jsonstr;
}


/**
 * Escape javascript code markers
 * @param  string  $str the string or array to process
 * @return string
 */
function trim_script($str) {
	if(is_array($str)){
		foreach ($str as $key => $val){
			$str[$key] = trim_script($val);
		}
 	}else{
 		$str = preg_replace ( '/\<([\/]?)script([^\>]*?)\>/si', '&lt;\\1script\\2&gt;', $str );
		$str = preg_replace ( '/\<([\/]?)iframe([^\>]*?)\>/si', '&lt;\\1iframe\\2&gt;', $str );
		$str = preg_replace ( '/\<([\/]?)frame([^\>]*?)\>/si', '&lt;\\1frame\\2&gt;', $str );
		$str = str_replace ( 'javascript:', 'javascript：', $str );
 	}
	return $str;
}


/**
* Convert a string to an array
* @param  string  $data string
* @return array Returns an array; if data is empty, returns an empty array
*/
function string2array($data) {
	$data = is_string($data) ? trim($data) : '';
	if(empty($data)) return array();
	
	if(version_compare(PHP_VERSION,'5.4.0','<')) $data = stripslashes($data);
	$array = json_decode($data, true);
	return is_array($array) ? $array : array();
}


/**
* Convert an array to a string
* @param  array  $data array
* @param  bool  $isformdata if processed with new_stripslashes; optional, defaults to 1
* @return string returns a string; if data is empty, returns empty
*/
function array2string($data, $isformdata = 1) {
	if(empty($data)) return '';
	
	if($isformdata) $data = new_stripslashes($data);
	if(version_compare(PHP_VERSION,'5.4.0','<')){
		return addslashes(json_encode($data));
	}else{
		return json_encode($data, JSON_UNESCAPED_UNICODE|JSON_FORCE_OBJECT);
	}
}


/**
 * Compatible array_column for lower PHP versions
 * @param  array   $array      the multi-dimensional array
 * @param  string  $column_key the column whose value is returned
 * @param  string  $index_key  Optional. The column to use as the index/key of the returned array; defaults to null
 * @return array       Returns an array whose values are the values of a single column of the input array.
 */
function yzm_array_column($array, $column_key, $index_key = null){
	if(function_exists('array_column')) return array_column($array, $column_key, $index_key);

    $result = array();
	foreach ($array as $key => $value) {
		if(!is_array($value)) continue;
        if($column_key){
        	if(!isset($value[$column_key])) continue;
        	$tmp = $value[$column_key];
        }else{
        	$tmp = $value;
        }
        if ($index_key) {
        	$key = isset($value[$index_key]) ? $value[$index_key] : $key;
        }
        $result[$key] = $tmp;
    }
    return $result;
}


/**
 * Check whether the email format is correct
 * @param  string  $email the email address
 * @return bool
 */
function is_email($email) {
	if(!is_string($email)) return false;
	return strlen($email) > 6 && preg_match("/^[\w\-\.]+@[\w\-\.]+(\.\w+)+$/", $email);
}


/**
 * Check whether the mobile format is correct
 * @param  string  $mobile the mobile number
 * @return bool
 */
function is_mobile($mobile) {
	return is_string($mobile) && preg_match('/1[3456789]{1}\d{9}$/',$mobile);
}


/**
 * Detect whether the input contains invalid characters
 * @param string $string the name of the string to check
 * @return bool
 */
function is_badword($string) {
	$badwords = array("\\",'&',' ',"'",'"','/','*',',','<','>',"\r","\t","\n","#");
	foreach($badwords as $value){
		if(strpos($string, $value) !== false) {
			return true;
		}
	}
	return false;
}


/**
 * Check whether the user name conforms to the rules
 * @param string $username the user name to check
 * @return 	boolean
 */
function is_username($username) {
	if(!is_string($username)) return false;
	$strlen = strlen($username);
	if(is_badword($username) || !preg_match("/^[a-zA-Z0-9_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]+$/", $username)){
		return false;
	} elseif ( $strlen > 30 || $strlen < 3 ) {
		return false;
	}
	
	//When a new user name is not all digits, it cannot start with a digit
	if(preg_match('/^\d*$/', $username)){
		return true;
	}
	if(preg_match('/^\d\S/', $username)){
		return false;
	}
	
	return true;
}



/**
 * Check whether the password length conforms to the rules
 * @param STRING $password
 * @return 	boolean
 */
function is_password($password) {
	$strlen = is_string($password) ? strlen($password) : 0;
	if($strlen >= 6 && $strlen <= 20) return true;
	return false;
}


/**
 * Get the file extension
 * @param  string  $filename the file name
 * @return string
 */
function fileext($filename) {
	return strtolower(trim(substr(strrchr($filename, '.'), 1, 10)));
}


/**
 * Whether it is an image format
 * @param  string  $ext the file extension
 * @return bool
 */
function is_img($ext) {
	return in_array(strtolower($ext), array('png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'ico'));
}



/**
 * IE browser detection
 * @return bool
 */
function is_ie() {
	$useragent = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
	if((strpos($useragent, 'opera') !== false) || (strpos($useragent, 'konqueror') !== false)) return false;
	if(strpos($useragent, 'msie ') !== false) return true;
	return false;
}


/**
 * Check whether a string is UTF-8 encoded; returns true for English and half-width characters
 * @param  string  $string the string to check
 * @return bool
 */
function is_utf8($string) {
	return preg_match('%^(?:
					[\x09\x0A\x0D\x20-\x7E] # ASCII
					| [\xC2-\xDF][\x80-\xBF] # non-overlong 2-byte
					| \xE0[\xA0-\xBF][\x80-\xBF] # excluding overlongs
					| [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2} # straight 3-byte
					| \xED[\x80-\x9F][\x80-\xBF] # excluding surrogates
					| \xF0[\x90-\xBF][\x80-\xBF]{2} # planes 1-3
					| [\xF1-\xF3][\x80-\xBF]{3} # planes 4-15
					| \xF4[\x80-\x8F][\x80-\xBF]{2} # plane 16
					)*$%xs', $string);
}


/**
 * Get the real MIME type of a file
 * @param string $file_path the file path
 * @param string $extension the file extension; returns the accurate type when finfo and mime_content_type are not enabled
 * @return string|bool
 */
function get_file_mime_type($file_path, $extension = null) {
    if (!is_file($file_path)) {
        return false;
    }

    if (function_exists('finfo_open') && function_exists('finfo_file')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = finfo_file($finfo, $file_path);
            safe_finfo_close($finfo);
            if ($mime !== false && $mime !== '') {
                return $mime;
            }
        }
    }

    if (function_exists('mime_content_type')) {
        $mime = mime_content_type($file_path);
        if ($mime !== false && $mime !== '') {
            return $mime;
        }
    }

    $extension = $extension ? $extension : strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
    $mime_types = array(
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'gif'  => 'image/gif',
        'webp' => 'image/webp',
        'bmp'  => 'image/bmp',
        'svg'  => 'image/svg+xml'
    );

    return isset($mime_types[$extension]) ? $mime_types[$extension] : 'application/octet-stream';
}



/**
 * File download
 * @param  string  $filepath the file path
 * @param  string  $filename the file name; when empty, the file name is used as the download name
 * @return null
 */
function file_down($filepath, $filename = '') {
    if (!is_file($filepath) || !is_readable($filepath)) {
        send_http_status(404);
        exit;
    }

    if(!$filename) $filename = basename($filepath);
    if(is_ie()) $filename = rawurlencode($filename);
    if(function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $filetype = finfo_file($finfo, $filepath);
        safe_finfo_close($finfo);
    } else {
        if (function_exists('mime_content_type')) {
            $filetype = mime_content_type($filepath);
        } else {
            $filetype = 'application/octet-stream';
        }
    }
    $filesize = sprintf("%u", filesize($filepath));
    if(ob_get_length() !== false) @ob_end_clean();
    header('Pragma: public');
    header('Last-Modified: '.gmdate('D, d M Y H:i:s') . ' GMT');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Cache-Control: pre-check=0, post-check=0, max-age=0');
    header('Content-Transfer-Encoding: binary');
    header('Content-Encoding: none');
    header('Content-type: '.$filetype);
    header('Content-Disposition: attachment; filename="'.$filename.'"');
    header('Content-length: '.$filesize);
    $file = fopen($filepath, 'rb');
    fpassthru($file);
    fclose($file);
    exit;
}


/**
* Pass a date or timestamp and return the gap from the current time, e.g. 1 minute ago, 2 hours ago, 5 months ago, 3 years ago, etc.
* @param string $date in two formats: date format "2015-09-12 14:16:12" or timestamp format "1386743303"
* @param int $type 1 for timestamp format, $type = 2 for date format
* @return string
*/
function format_time($date = 0, $type = 1) {
	if($type == 2) $date = strtotime($date);
    $second = SYS_TIME - $date;
    $minute = floor($second / 60) ? floor($second / 60) : 1; 
    if ($minute >= 60 && $minute < (60 * 24)) { 
        $hour = floor($minute / 60); 
    } elseif ($minute >= (60 * 24) && $minute < (60 * 24 * 30)) { 
        $day = floor($minute / ( 60 * 24)); 
    } elseif ($minute >= (60 * 24 * 30) && $minute < (60 * 24 * 365)) { 
        $month = floor($minute / (60 * 24 * 30));
    } elseif ($minute >= (60 * 24 * 365)) { 
        $year = floor($minute / (60 * 24 * 365)); 
    }
    if (isset($year)) {
        return $year . ' years ago';
    } elseif (isset($month)) {
        return $month . ' months ago';
    } elseif (isset($day)) {
        return $day . ' days ago';
    } elseif (isset($hour)) {
        return $hour . ' hours ago';
    } elseif (isset($minute)) {
        return $minute . ' minutes ago';
    }
}		


/**
 * Convert bytes to other units
 * @param  int	$size	the byte size
 * @param  int	$prec	the number of digits after the decimal point
 * @return string	the formatted size
 */
function sizecount($size, $prec = 2) {
	$size = floatval($size);
	$arr = array('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB');
	$pos = 0;
	while ($size >= 1024) {
	    $size /= 1024;
	    $pos++;
	}
	return round($size, $prec).' '.$arr[$pos];
}


/**
 * Perform encoding conversion on data
 * @param array|string $data       an array or a string
 * @param string $input     the encoding to convert from
 * @param string $output    the encoding to convert to
 * @return string|array
 */
function array_iconv($data, $input = 'gbk', $output = 'utf-8') {
	if (!is_array($data)) {
		return iconv($input, $output, $data);
	} else {
		foreach ($data as $key=>$val) {
			if(is_array($val)) {
				$data[$key] = array_iconv($val, $input, $output);
			} else {
				$data[$key] = iconv($input, $output, $val);
			}
		}
		return $data;
	}
}


/**
* String encryption/decryption function
* @param	string	$string		string
* @param	string	$operation	ENCODE for encryption, DECODE for decryption; optional, defaults to ENCODE,
* @param	string	$key		the key: digits, letters, underscores
* @param	string	$expiry		the expiration time
* @return	string
*/
function string_auth($string, $operation = 'ENCODE', $key = '', $expiry = 0) {
	$ckey_length = 4;
	$key = md5($key != '' ? $key : C('auth_key'));
	$keya = md5(substr($key, 0, 16));
	$keyb = md5(substr($key, 16, 16));
	$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($string, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';

	$cryptkey = $keya.md5($keya.$keyc);
	$key_length = strlen($cryptkey);

	$string = $operation == 'DECODE' ? base64_decode(strtr(substr($string, $ckey_length), '-_', '+/')) : sprintf('%010d', $expiry ? $expiry + SYS_TIME : 0).substr(md5($string.$keyb), 0, 16).$string;
	$string_length = strlen($string);

	$result = '';
	$box = range(0, 255);

	$rndkey = array();
	for($i = 0; $i <= 255; $i++) {
		$rndkey[$i] = ord($cryptkey[$i % $key_length]);
	}

	for($j = $i = 0; $i < 256; $i++) {
		$j = ($j + $box[$i] + $rndkey[$i]) % 256;
		$tmp = $box[$i];
		$box[$i] = $box[$j];
		$box[$j] = $tmp;
	}

	for($a = $j = $i = 0; $i < $string_length; $i++) {
		$a = ($a + 1) % 256;
		$j = ($j + $box[$a]) % 256;
		$tmp = $box[$a];
		$box[$a] = $box[$j];
		$box[$j] = $tmp;
		$result .= chr(ord($string[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
	}

	if($operation == 'DECODE') {
		if((substr($result, 0, 10) == 0 || intval(substr($result, 0, 10)) - SYS_TIME > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
			return substr($result, 26);
		} else {
			return '';
		}
	} else {
		return $keyc.rtrim(strtr(base64_encode($result), '+/', '-_'), '=');
	}
}


/**
 * Get the images in the content
 * @param string $content the content
 * @return string
 */
function match_img($content){
    preg_match("/(src)=([\"|']?)([^ \"'>]+\.(gif|jpg|jpeg|bmp|png|webp))\\2/i", $content, $match);
    return isset($match[3]) ? $match[3] : ''; 
}


/**
 * Fetch remote images and save them locally; make sure you have permission to write files to the local server
 * @param string $content the article content
 * @param string $targeturl Optional; the URL of the other site, to handle cases where the other site uses image paths like "/upload/1.jpg"
 * @return string $content the processed content
 */
function grab_image($content, $targeturl = ''){
	preg_match_all("/(src)=([\"|']?)([^ \"'>]+\.(gif|jpg|jpeg|bmp|png|webp))\\2/i", $content, $img_array);
	$img_array = isset($img_array[3]) ? array_unique($img_array[3]) : array();
	if(!$img_array) return $content;
	
	$path =  C('upload_file').'/'.date('Ym/d');
	$urlpath = SITE_PATH.$path;
	$imgpath =  YZMPHP_PATH.$path;
	if(!is_dir($imgpath)) @mkdir($imgpath, 0777, true);
	
	foreach($img_array as $value){
		$val = $value;		
		if(strpos($value, 'http') === false){
			if(!$targeturl) continue;
			$value = $targeturl.$value;
		}	
		if(strpos($value, '?')){ 
			$value = explode('?', $value);
			$value = $value[0];
		}
		if(substr($value, 0, 4) != 'http'){
			continue;
		}
		$ext = fileext($value);
		if(!is_img($ext)) continue;
		$imgname = date('YmdHis').rand(100,999).'.'.$ext;
		$filename = $imgpath.'/'.$imgname;
		$urlname = $urlpath.'/'.$imgname;
		
		ob_start();
		@readfile($value);
		$data = ob_get_contents();
		ob_end_clean();
		$data && file_put_contents($filename, $data);
	 
		if(is_file($filename)){                         
			$content = str_replace($val, $urlname, $content);
		}
	}
	return $content;        
}


/**
 * Thumbnail generation function
 * @param  string  $imgurl the image path
 * @param  int  $width  thumbnail width
 * @param  int  $height thumbnail height
 * @param  int  $autocut whether to crop automatically; disabled by default, and automatically disabled when either height or width is 0
 * @param  string  $smallpic the default image path when there is no image
 * @return string
 */
function thumb($imgurl, $width = 300, $height = 200 ,$autocut = 0, $smallpic = 'nopic.jpg') {
	global $image;
	$upload_url = SITE_PATH.C('upload_file').'/';
	$upload_path = YZMPHP_PATH.C('upload_file').'/';
	if(empty($imgurl)) return STATIC_URL.'images/'.$smallpic;
	if(!strpos($imgurl, '://')) $imgurl = SERVER_PORT.HTTP_HOST.$imgurl;
	$imgurl_replace= str_replace(SITE_URL.C('upload_file').'/', '', $imgurl); 
	if(!extension_loaded('gd') || strpos($imgurl_replace, '://')) return $imgurl;
	if(!is_file($upload_path.$imgurl_replace)) return STATIC_URL.'images/'.$smallpic;

	list($width_t, $height_t, $type, $attr) = getimagesize($upload_path.$imgurl_replace);
	if($width>=$width_t || $height>=$height_t) return $imgurl;

	$newimgurl = dirname($imgurl_replace).'/thumb_'.$width.'_'.$height.'_'.basename($imgurl_replace);

	if(is_file($upload_path.$newimgurl)) return $upload_url.$newimgurl;

	if(!is_object($image)) {
		yzm_base::load_sys_class('image','','0');
		$image = new image(1);
	}
	return $image->thumb($upload_path.$imgurl_replace, $upload_path.$newimgurl, $width, $height, '', $autocut) ? $upload_url.$newimgurl : $imgurl;
}


/**
 * Watermark addition
 * @param  string  $source the original image path
 * @param  string  $target the path for the generated watermark image; defaults to empty, which overwrites the original image
 * @return string
 */
function watermark($source, $target = '') {
	global $image_w;
	if(empty($source)) return $source;
	if(strpos($source, '://')) $source = str_replace(SERVER_PORT.HTTP_HOST, '', $source);
	if(!extension_loaded('gd') || strpos($source, '://')) return $source;
	
	if(!is_object($image_w)){
		yzm_base::load_sys_class('image','','0');
		$image_w = new image(1,1);
	}

	if(SITE_PATH == '/'){
		$source = YZMPHP_PATH.$source;
		$target = $target ? YZMPHP_PATH.$target : $source;
		$image_w->watermark($source, $target);
		return str_replace(YZMPHP_PATH, '', $target);
	}else{
		$source = YZMPHP_PATH.str_replace(SITE_PATH, '', $source);
		$target = $target ? YZMPHP_PATH.str_replace(SITE_PATH, '', $target) : $source;
		$image_w->watermark($source, $target);
		return SITE_PATH.str_replace(YZMPHP_PATH, '', $target);
	}
}


/**
 * Start SESSION with httponly
 * @return bool
 */
function new_session_start(){
	if(ini_get('session.auto_start')) return true;
	// session_save_path(YZMPHP_PATH.'cache/sessions');
	ini_set('session.cookie_httponly', true);
	$session_name = session_name();
	if (isset($_COOKIE[$session_name]) && !preg_match('/^[-,a-zA-Z0-9]{1,128}$/', $_COOKIE[$session_name])) {
        unset($_COOKIE[$session_name]);
    } 
	return session_start();
}


/**
 * Set a cookie
 * @param string $name     the variable name
 * @param string $value    the variable value
 * @param int $time    the expiration time
 * @param boolean $httponly
 */
function set_cookie($name, $value = '', $time = 0, $httponly = false) {
	$time = $time ? SYS_TIME + $time : (C('cookie_ttl') ? SYS_TIME + C('cookie_ttl') : 0);
	$name = C('cookie_pre').$name;
	$value = is_array($value) ? 'in_yzmphp'.string_auth(json_encode($value),'ENCODE',md5(YZMPHP_PATH.C('db_pwd'))) : string_auth($value,'ENCODE',md5(YZMPHP_PATH.C('db_pwd')));
	$httponly = $httponly ? $httponly : C('cookie_httponly');
	setcookie($name, $value, $time, C('cookie_path'), C('cookie_domain'), C('cookie_secure'), $httponly);
	$_COOKIE[$name] = $value;
}


/**
 * Get a cookie
 * @param string $name     	  the variable name; if omitted, get all cookies
 * @param string $default     the default value, returned when the value does not exist
 * @return string
 */
function get_cookie($name = '', $default = '') {
	if(!$name) return $_COOKIE;
	$name = C('cookie_pre').$name;
	if(isset($_COOKIE[$name])){
		if(strpos($_COOKIE[$name],'in_yzmphp')===0){
			$temp = substr($_COOKIE[$name],9);
			return json_decode(MAGIC_QUOTES_GPC?stripslashes(string_auth($temp,'DECODE',md5(YZMPHP_PATH.C('db_pwd')))):string_auth($temp,'DECODE',md5(YZMPHP_PATH.C('db_pwd'))), true);
        }
		return string_auth(safe_replace($_COOKIE[$name]),'DECODE',md5(YZMPHP_PATH.C('db_pwd')));
	}else{
		return $default;
	}	
}


/**
 * Delete a cookie
 * @param string $name     the variable name; if omitted, delete all cookies
 * @return bool
 */
function del_cookie($name = '') {	
	if(!$name){
		foreach($_COOKIE as $key => $val) { 
			setcookie($key, '', SYS_TIME - 3600, C('cookie_path'), C('cookie_domain'), C('cookie_secure'), C('cookie_httponly'));
			unset($_COOKIE[$key]);
		}		
	}else{
		$name = C('cookie_pre').$name;
		if(!isset($_COOKIE[$name])) return true;
		setcookie($name, '', SYS_TIME - 3600, C('cookie_path'), C('cookie_domain'), C('cookie_secure'), C('cookie_httponly'));
		unset($_COOKIE[$name]);
	}
	return true;
}


/**
 * New way to get configuration parameters
 * @param string $key  the config key to get, e.g. database or database.host
 * @param string $default  the default value, used when getting the config item fails.
 * @return mixed
 */
function config($key = '', $default = '') {
    $k = explode('.', $key);
    static $cfg = array(); 
    if (!isset($cfg[$k[0]])) {
        $path = YZMPHP_PATH.'common'.DIRECTORY_SEPARATOR.'config'.DIRECTORY_SEPARATOR.$k[0].'.php';
        if (is_file($path)) { 
            $cfg[$k[0]] = include $path;
        }else{
            return $default;
        }
    }
    return count($k)==1 ? $cfg[$k[0]] : (isset($cfg[$k[0]][$k[1]]) ? $cfg[$k[0]][$k[1]] : $default);
}


/**
 * Get the env configuration
 * @param string $env_key the parameter key
 * @param string $default the default value
 * @return string|bool
 */
function env($env_key, $default = '') {
    static $env_data = array();

    if (empty($env_data)) {
        $env_file = YZMPHP_PATH . '.env';

        if (!is_file($env_file)) return $default;
        $lines = file($env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);

            if (empty($line) || strpos($line, '#') === 0) {
                continue;
            }

            if (preg_match('/^([^=]+)=(.*)$/', $line, $matches)) {
                $key = trim($matches[1]);
                $value = trim($matches[2]);

                if ($value === '') {
                    $env_data[$key] = '';
                    continue;
                }

                $pattern = '/^[\s]*([\'"])(.*?)(?<!\\\\)\1(?=\s*#|$)/';
                if (preg_match($pattern, $value, $matches)) {
                    $value = $matches[2]; 
                } else {
                    $parts = explode('#', $value, 2);
                    $value = trim($parts[0]);
                }

                $normalizedValue = strtolower($value);
                if ($normalizedValue === 'true') {
                    $value = true;
                } elseif ($normalizedValue === 'false') {
                    $value = false;
                } elseif (is_numeric($value)) {
                    $value = $value + 0;
                }

                $env_data[$key] = $value;
            }
        }
    }

    return isset($env_data[$env_key]) ? $env_data[$env_key] : $default;
}


/**
 * Used to instantiate a model object
 * @param string $classname the model name
 * @param string $m the module
 * @return object
 */	
function M($classname, $m = ''){
	return yzm_base::load_model($classname, $m);
}



/**
 * Used to instantiate a data table object, e.g. D('admin');
 * @param  string  $tabname	 the table name
 * @return object
 */	
function D($tabname){
	static $_tables  = array();
	if(isset($_tables[$tabname])) return $_tables[$tabname];
	yzm_base::load_sys_class('db_factory', '', 0);
	$object = db_factory::get_instance()->connect($tabname);
	$_tables[$tabname] = $object;
	return $object;
}


/**
 * URL assembly, supports different URL modes
 * @param string $url URL expression, format: '[the module/controller/action]'
 * @param string|array $vars the parameters to pass, supports strings and arrays
 * @param boolean $domain whether to show the domain; by default shown automatically based on the URL mode
 * @param string|boolean $suffix the pseudo-static suffix; true means get the value from the config
 * @return string
 */
function U($url='', $vars='', $domain=null, $suffix=true) {	
	$url = trim($url, '/');
	$arr = explode('/', $url);
	$num = count($arr);

	$string = SITE_PATH;
	if(URL_MODEL == 0){
		$string .= 'index.php?';
		if($num == 3){
			$string .= 'm='.$arr[0].'&c='.$arr[1].'&a='.$arr[2];
		}elseif($num == 2){
			$string .= 'm='.ROUTE_M.'&c='.$arr[0].'&a='.$arr[1];
		}else{
			$string .= 'm='.ROUTE_M.'&c='.ROUTE_C.'&a='.$arr[0];
		}

		if($vars){
			if(is_array($vars)) $vars = http_build_query($vars);
			$string .= '&'.$vars;
		}
	}else{
		if(URL_MODEL == 1) $string .= 'index.php?s=';
		if(URL_MODEL == 4) $string .= 'index.php/';
		
		if($num == 3){
			$string .= $url;
		}elseif($num == 2){
			$string .= ROUTE_M.'/'.$url;
		}else{
			$string .= ROUTE_M.'/'.ROUTE_C.'/'.$url;
		}

		if($vars){
			if(!is_array($vars)) parse_str($vars, $vars);			
            foreach ($vars as $var => $val){
				if(!is_array($val) && trim($val) !== '') {
					$val = str_replace('/', '{YZM_PATH}', $val);
					$string .= '/'.urlencode($var).'/'.urlencode($val);
				}
            } 
		}
        $string .= $suffix === true ? C('url_html_suffix') : $suffix;		
	}

	$string = $domain===null&&URL_MODEL==3 ? SERVER_PORT.HTTP_HOST.$string : ($domain ? SERVER_PORT.HTTP_HOST.$string : $string);
	
	return $string;
}


/**
 * Get configuration parameters
 * @param string $key  the config key to get
 * @param string $default  the default value, used when getting the config item fails.
 * @return mixed
 */
function C($key = '', $default = '') {
    static $configs = array(); 
	if (isset($configs['config'])) {
		if (empty($key)) {
			return $configs['config'];
		} elseif (isset($configs['config'][$key])) {
			return $configs['config'][$key];
		} else {
			return $default;
		}
	}
	$path = YZMPHP_PATH.'common'.DIRECTORY_SEPARATOR.'config'.DIRECTORY_SEPARATOR.'config.php';
	if (is_file($path)) { 
		$configs['config'] = include $path;
	}
	if (empty($key)) {
		return $configs['config'];
	} elseif (isset($configs['config'][$key])) {
		return $configs['config'][$key];
	} else {
		return $default;
	}
}


/**
 * Get and set the language definition
 * @param string $language the language variable
 * @param string $module     the module name
 * @return string the language string
 */
function L($language = '', $module = ''){
	static $_lang = array();
	if(empty($language)) return $_lang;
        
	$lang = C('language');
	$module = empty($module) ? ROUTE_M : $module;
	if(!$_lang) { 
		$sys_lang = require(YP_PATH.'language'.DIRECTORY_SEPARATOR.$lang.'.lang.php');
		$module_lang = array();
		if(is_file(APP_PATH.$module.DIRECTORY_SEPARATOR.'common'.DIRECTORY_SEPARATOR.'language'.DIRECTORY_SEPARATOR.$lang.'.lang.php')){
			$module_lang = require(APP_PATH.$module.DIRECTORY_SEPARATOR.'common'.DIRECTORY_SEPARATOR.'language'.DIRECTORY_SEPARATOR.$lang.'.lang.php');
		}
		$_lang = array_merge($sys_lang, $module_lang);
	}
	if(array_key_exists($language,$_lang)) {
		return $_lang[$language];
	}
	
	return $language;
}


/**
 * Print data of various types; used when debugging.
 * @param mixed $var the variable; multiple values are supported
 * @return null
 */
function P($var){
	foreach(func_get_args() as $value){
		echo '<pre style="background:#18171B;color:#EBEBEB;border-radius:3px;padding:5px 8px;margin:8px 0;font:12px Menlo, Monaco, Consolas, monospace;word-wrap:break-word;white-space:pre-wrap">';
		var_dump($value);
		echo '</pre>';
	}
	return null;
}


/**
 * Used to temporarily suppress debug info
 * @return null
 */	
function debug(){
	defined('DEBUG_HIDDEN') or define('DEBUG_HIDDEN', true);
}


/**
 * Used to set the module theme
 * @return null
 */	
function set_module_theme($theme = 'default'){
	defined('MODULE_THEME') or define('MODULE_THEME', $theme);
}


/**
 * Write to the cache
 * @param  string  $name the cache name
 * @param  mixed  $data the cache data
 * @param  int  $timeout the expiration time
 * @return    int
 */
function setcache($name, $data, $timeout=0) {
	yzm_base::load_sys_class('cache_factory','',0);
	$cache = cache_factory::get_instance()->get_cache_instances();
	return $cache->set($name, $data, $timeout);
}


/**
 * Read the cache
 * @param string $name the cache name
 * @return mixed
 */
function getcache($name) {
	yzm_base::load_sys_class('cache_factory','',0);
	$cache = cache_factory::get_instance()->get_cache_instances();
	return $cache->get($name);
}


/**
 * Delete the cache
 * @param string $name the cache name
 * @param bool $flush whether to clear all caches
 * @return bool
 */
function delcache($name, $flush = false) {
	yzm_base::load_sys_class('cache_factory','',0);
	$cache = cache_factory::get_instance()->get_cache_instances();
	return !$flush ? $cache->delete($name) : $cache->flush();
}


/**
 * Template invocation
 * @param  string $module   the module name
 * @param  string $template the template name
 * @param  string $theme    force the template style
 * @return void           
 */
function template($module = '', $template = 'index', $theme = ''){
	if(!$module) $module = 'index';
	$template_c = YZMPHP_PATH.'cache'.DIRECTORY_SEPARATOR.$module.DIRECTORY_SEPARATOR;
	$theme = !$theme ? (!defined('MODULE_THEME') ? C('site_theme') : MODULE_THEME) : $theme;
	$template_path = APP_PATH.$module.DIRECTORY_SEPARATOR.'view'.DIRECTORY_SEPARATOR.$theme.DIRECTORY_SEPARATOR;
    $filename = $template.'.html';
	$tplfile = $template_path.$filename;   
	if(!is_file($tplfile)) {
		$template = APP_DEBUG ? str_replace(YZMPHP_PATH, '', $tplfile) : basename($tplfile);
		showmsg($template.L('template_does_not_exist'), 'stop');			                      
	}	
	if(!is_dir(YZMPHP_PATH.'cache'.DIRECTORY_SEPARATOR.$module.DIRECTORY_SEPARATOR)){
		@mkdir(YZMPHP_PATH.'cache'.DIRECTORY_SEPARATOR.$module.DIRECTORY_SEPARATOR, 0777, true);
	}
	$template = basename($template).'_'.md5($template_path.$template);	
	$template_c = $template_c.$template.'.tpl.php'; 		
	if(!is_file($template_c) || filemtime($template_c) < filemtime($tplfile)) {
		$yzm_tpl = yzm_base::load_sys_class('yzm_tpl');
		$compile = $yzm_tpl->tpl_replace(@file_get_contents($tplfile));
		file_put_contents($template_c, $compile);
	}
	return $template_c;
}


/**
 * Dispatch a queue job
 * @param  string $job    the queue job class name
 * @param  array  $params the parameters to pass
 * @param  string $queue  the queue name
 * @return string|false   the job id
 */
function dispatch($job, $params = array(), $queue = ''){
    $res = yzm_base::load_job($job, 0);
    if(!$res) return $res;

    $object = new $job($params);
    yzm_base::load_sys_class('queue_factory','',0);

    $data = array(
        'uuid' => md5(create_randomstr()),
        'job' => $job,
        'object' => serialize($object),
        'attempts' => 0,
        'create_time' => SYS_TIME
    );
    queue_factory::get_instance()->lpush($queue ? $queue : trim(C('queue_name')), $data);
    return $data['uuid'];
}


/**
 *  Message page redirect
 *
 * @param string $msg      the message prompt info
 * @param string $gourl    the redirect URL; stop means stop
 * @param int $limittime  the time limit
 * @return void
 */
function showmsg($msg, $gourl = '', $limittime = 3){
	application::showmsg($msg, $gourl, $limittime);
	if(APP_DEBUG){
		debug::stop();
		debug::message();
	}
	exit;
}


/**
 * Automatically return info based on the request method
 * @param  string  $message 
 * @param  int  $status  
 * @param  string  $url
 * @return  void           
 */
function return_message($message, $status = 1, $url = ''){
	$data = array('status'=>$status, 'message'=>$message);
	if($url) $data['url'] = $url;
	is_ajax() && return_json($data);
	showmsg($message, $url ? $url : ($status ? '' : 'stop'));
}


/**
 * Send an HTTP status
 * @param integer $code the status code
 * @return void
 */
function send_http_status($code){
    static $_status = array(
            // Informational 1xx
            100 => 'Continue',
            101 => 'Switching Protocols',
            // Success 2xx
            200 => 'OK',
            201 => 'Created',
            202 => 'Accepted',
            203 => 'Non-Authoritative Information',
            204 => 'No Content',
            205 => 'Reset Content',
            206 => 'Partial Content',
            // Redirection 3xx
            300 => 'Multiple Choices',
            301 => 'Moved Permanently',
            302 => 'Moved Temporarily ',  // 1.1
            303 => 'See Other',
            304 => 'Not Modified',
            305 => 'Use Proxy',
            // 306 is deprecated but reserved
            307 => 'Temporary Redirect',
            // Client Error 4xx
            400 => 'Bad Request',
            401 => 'Unauthorized',
            402 => 'Payment Required',
            403 => 'Forbidden',
            404 => 'Not Found',
            405 => 'Method Not Allowed',
            406 => 'Not Acceptable',
            407 => 'Proxy Authentication Required',
            408 => 'Request Timeout',
            409 => 'Conflict',
            410 => 'Gone',
            411 => 'Length Required',
            412 => 'Precondition Failed',
            413 => 'Request Entity Too Large',
            414 => 'Request-URI Too Long',
            415 => 'Unsupported Media Type',
            416 => 'Requested Range Not Satisfiable',
            417 => 'Expectation Failed',
            // Server Error 5xx
            500 => 'Internal Server Error',
            501 => 'Not Implemented',
            502 => 'Bad Gateway',
            503 => 'Service Unavailable',
            504 => 'Gateway Timeout',
            505 => 'HTTP Version Not Supported',
            509 => 'Bandwidth Limit Exceeded',
            550 => 'Can not connect to MySQL server'
    );
    if(isset($_status[$code])) {
        header('HTTP/1.1 '.$code.' '.$_status[$code]);
        // Ensure it works in FastCGI mode
        header('Status:'.$code.' '.$_status[$code]);
    }
}	


/**
 * Generate a verification key
 * @param  string  $prefix   the prefix
 * @return string
 */
function make_auth_key($prefix) {
	return md5($prefix.YZMPHP_PATH.C('auth_key'));
}


/**
 * Return a json array, with the default message "Data not modified!" 
 * @param $arr
 * @param $show_debug
 * @return string
 */
function return_json($arr = array(), $show_debug = false){
	header("X-Powered-By: YZMPHP/YzmCMS.");
    header('Content-Type:application/json; charset=utf-8');
    if(!$arr) $arr = array('status'=>0,'message'=>L('data_not_modified'));
	if(APP_DEBUG || $show_debug) $arr = array_merge($arr, debug::get_debug());
    exit(new_json_encode($arr, JSON_UNESCAPED_UNICODE));
}


/**
 * Write a log
 * @param  string  $message the log message
 * @param  string  $filename the file name
 * @param  string  $ext the file extension
 * @param  string  $path the log path
 * @return bool
 */
function write_log($message, $filename = '', $ext = '.log', $path = '') {
	$message = is_array($message) ? new_json_encode($message, JSON_UNESCAPED_UNICODE) : $message;
	$message = date('Y-m-d H:i:s').' '.$message."\r\n";
	if(!$path) $path = YZMPHP_PATH.'cache/syslog';
	if(!is_dir($path)) @mkdir($path, 0777, true);
	
	if(!$filename) $filename = date('Ymd').$ext;
	
	return error_log($message, 3, $path.DIRECTORY_SEPARATOR.$filename);
}


/**
 * Write an error log
 * @param  array  $err_arr the error info
 * @param  string  $path the log path
 * @return bool
 */
function write_error_log($err_arr, $path = '') {
	if(!C('error_log_save') || defined('CLOSE_WRITE_LOG')) return false;
	$err_arr = is_array($err_arr) ? $err_arr : array($err_arr);
	$message[] = date('Y-m-d H:i:s');
	$message[] = get_url();
	$message[] = getip();
	if(isset($_POST) && !empty($_POST)) $message[] = new_json_encode($_POST, JSON_UNESCAPED_UNICODE);
	$message = array_merge($message, $err_arr);
	$message = join(' | ', $message)."\r\n";
	if(!$path) $path = YZMPHP_PATH.'cache';
	if(!is_dir($path)) @mkdir($path, 0777, true);
	$file = $path.DIRECTORY_SEPARATOR.'error_log.php';
	if(is_file($file)){
		if(!is_writable($file)) return false;
		if(filesize($file)>20971520){
			@rename($file, $path.DIRECTORY_SEPARATOR.'error_log'.date('YmdHis').rand(100,999).'.php') ;
		}
	}
	
	if(!is_file($file)){
		error_log("<?php exit;?>\r\n", 3, $file);
	}
	return error_log($message, 3, $file);
}


/**
 * URL redirect
 * @param string $url the redirect URL
 * @param integer $time the wait time before redirect (seconds)
 * @param string $msg the prompt info before redirect
 * @return void
 */
function redirect($url, $time=0, $msg='') {
    if (empty($msg))
        $msg    = 'The system will redirect in '.$time.' seconds to '.$url.'!';
    if (!headers_sent()) {
        if (0 === $time) {
            header('Location: ' . $url);
        } else {
            header('refresh:'.$time.';url='.$url);
            echo($msg);
        }
        exit();
    } else {
        $str    = '<meta http-equiv="Refresh" content="'.$time.';URL='.$url.'">';
        if ($time != 0)
            $str .= $msg;
        exit($str);
    }
}


/**
 * Get input data
 * @param string $key the variable name to get
 * @param mixed $default the default value
 * @param string $function the handling function
 * @return mixed
 */
function input($key = '', $default = '', $function = ''){
	if ($pos = strpos($key, '.')) {
		list($method, $key) = explode('.', $key, 2);
		if (!in_array($method, array('get', 'post', 'request'))) {
			$key    = $method . '.' . $key;
			$method = 'param';
		}
	} else {
		$method = 'param';
	}

	$method = strtolower($method);

	if ($method == 'get') {
		return empty($key) ? $_GET : (isset($_GET[$key]) ? ($function ? $function($_GET[$key]) : $_GET[$key]) : $default);
	} elseif ($method == 'post') {
		$_POST = $_POST ? $_POST : (file_get_contents('php://input') ? json_decode(file_get_contents('php://input'), true) : array());
		return empty($key) ? $_POST : (isset($_POST[$key]) ? ($function ? $function($_POST[$key]) : $_POST[$key]) : $default);
	} elseif ($method == 'request') {
		return empty($key) ? $_REQUEST : (isset($_REQUEST[$key]) ? ($function ? $function($_REQUEST[$key]) : $_REQUEST[$key]) : $default);
	} elseif ($method == 'param') {
		$param = array_merge($_GET, is_array($_POST)?$_POST:array(), $_REQUEST);
		return empty($key) ? $param : (isset($param[$key]) ? ($function ? $function($param[$key]) : $param[$key]) : $default);
	} else {
		return false;
	}
}


/**
 * Get HTTP_HOST
 * @return string
 */
function get_http_host(){
	$http_post = isset($_SERVER['HTTP_HOST']) ? htmlspecialchars($_SERVER['HTTP_HOST'], ENT_QUOTES) : '';
	$server_port = isset($_SERVER['SERVER_PORT']) ? intval($_SERVER['SERVER_PORT']) : 80;
	if(!$http_post) return $http_post;
	if(!strstr($http_post, ':') && !in_array($server_port, array(80, 443))) $http_post .= ':'.$server_port;
	return $http_post;
}


/**
 * Check whether the SSL protocol is used
 * @return bool
 */
function is_ssl() {
    if(isset($_SERVER['HTTPS']) && ('1' == $_SERVER['HTTPS'] || 'on' == strtolower($_SERVER['HTTPS']))){
        return true;
    }elseif(isset($_SERVER['SERVER_PORT']) && ('443' == $_SERVER['SERVER_PORT'])) {
        return true;
    }elseif(isset($_SERVER['REQUEST_SCHEME']) && ('https' == strtolower($_SERVER['REQUEST_SCHEME']))) {
        return true;
    }elseif(isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && ('https' == strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']))) {
        return true;
    }elseif(isset($_SERVER['HTTP_X_FORWARDED_SCHEME']) && ('https' == strtolower($_SERVER['HTTP_X_FORWARDED_SCHEME']))) {
        return true;
    }
    return false;
}


/**
 * Get the current entry file name
 * In CGI/FASTCGI mode, we need to cut off the PATH_INFO tail after .php in SCRIPT_NAME and remove the host name; other modes are used directly
 * @return string
 */
function get_php_file(){
	//Check whether it is running in CGI/FASTCGI mode
	if(0 === strpos(PHP_SAPI, 'cgi') || false !== strpos(PHP_SAPI, 'fcgi')){
		$temp = explode('.php', $_SERVER['SCRIPT_NAME']);
		return rtrim(str_replace(get_http_host(), '', $temp[0].'.php'), '/');
	}
	return rtrim($_SERVER['SCRIPT_NAME'], '/');
}


/**
 * Check whether it is a POST request
 * @return bool
 */
function is_post(){
	return 'POST' == $_SERVER['REQUEST_METHOD'];
}


/**
 * Check whether it is a GET request
 * @return bool
 */
function is_get(){
	return 'GET' == $_SERVER['REQUEST_METHOD'];
}


/**
 * Check whether it is a PUT request
 * @return bool
 */
function is_put(){
	return 'PUT' == $_SERVER['REQUEST_METHOD'];
}


/**
 * Check whether it is an AJAX request
 * @return bool
 */
function is_ajax(){
	return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH'])=='xmlhttprequest' ? true : false;
}


/**
 * Safely close the cURL handle
 * @param mixed $ch the cURL handle
 * @return null
 */
function safe_curl_close($ch) {
	if (!$ch) {
        return;
    }
    if (PHP_VERSION_ID < 80500 && function_exists('curl_close')) {
        @curl_close($ch);
    }
    return null;
}

/**
 * Safely close the file info handle
 * @param mixed $finfo the file info handle
 * @return null
 */
function safe_finfo_close($finfo) {
	if (!$finfo) {
        return;
    }
    if (PHP_VERSION_ID < 80500 && function_exists('finfo_close')) {
        @finfo_close($finfo);
    }
    return null;
}


/**
 * Create a TOKEN; make sure SESSION has been started
 * @param bool $isinput whether to return input
 * @return string
 */
function creat_token($isinput = true){
	if(!isset($_SESSION['yzm_csrf_token'])) $_SESSION['yzm_csrf_token'] = create_randomstr(8);
	return $isinput ? '<input type="hidden" name="token" value="'.$_SESSION['yzm_csrf_token'].'">' : $_SESSION['yzm_csrf_token'];
}


/**
 * Verify the TOKEN; make sure SESSION has been started
 * @param string $token 
 * @param bool $delete
 * @return bool
 */
function check_token($token, $delete=false){
	if(!$token || !isset($_SESSION['yzm_csrf_token']) || $token!=$_SESSION['yzm_csrf_token']) return false;
	if($delete) unset($_SESSION['yzm_csrf_token']);
	return true;
}